# -*- coding:utf-8 -*-
# @Script: constants.py
# @Author: Andre Litty
# @Email: alittysw@gmail.com
# @Create At: 2020-08-07 11:08:10
# @Last Modified By: Andre Litty
# @Last Modified At: 2020-09-10 11:10:45
# @Description: All constants for app gms_modem.

PATH_SUFFIX = 'gsm/'
