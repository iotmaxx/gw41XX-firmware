# -*- coding:utf-8 -*-
# @Script: constants.py
# @Author: Andre Litty
# @Email: alittysw@gmail.com
# @Create At: 2020-03-21 13:47:11
# @Last Modified By: Andre Litty
# @Last Modified At: 2020-04-05 20:58:48
# @Description: Constants for local network config.

PATH_SUFFIX = 'local_network/'
