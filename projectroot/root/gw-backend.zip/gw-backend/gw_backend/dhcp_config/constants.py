# -*- coding:utf-8 -*-
# @Script: constants.py
# @Author: Andre Litty
# @Email: alittysw@gmail.com
# @Create At: 2020-03-21 13:45:58
# @Last Modified By: Andre Litty
# @Last Modified At: 2020-04-05 20:58:55
# @Description: Constants for dhcp config.

PATH_SUFFIX = 'dhcp_config/'
